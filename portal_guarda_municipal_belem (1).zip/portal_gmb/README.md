# Portal demonstrativo — Guarda Municipal de Belém

## Como visualizar
1. Extraia o arquivo ZIP.
2. Abra `index.html` em um navegador moderno.

O portal é uma implementação front-end responsiva em HTML, CSS e JavaScript puro. Não exige instalação ou servidor para a demonstração.

## O que está implementado
- Navegação responsiva com menu mobile e cabeçalho fixo.
- Seções institucionais, estrutura, grupamentos, projetos, serviços, tecnologia, notícias, transparência e contato.
- Animações de entrada ao rolar, barra de progresso e botão voltar ao topo.
- Filtro de notícias, modais dos grupamentos e pesquisa por títulos.
- Controles simples de acessibilidade.
- Formulário validado que prepara uma mensagem no aplicativo de e-mail do visitante.
- Links de emergência 153 e rota no Google Maps.

## Importante antes de publicar
Este é um portal demonstrativo funcional, não uma publicação oficial. Os dados do endereço e e-mail foram transcritos do briefing fornecido e precisam ser confirmados. Os textos sobre unidades foram mantidos genéricos para não atribuir competências não verificadas. Os cards de notícias são demonstrativos. Substitua-os por notícias oficiais, conecte os documentos a URLs reais e valide organograma, contatos, canais de Ouvidoria/Corregedoria, horários e identidade visual oficial. O formulário não transmite dados a um servidor.
